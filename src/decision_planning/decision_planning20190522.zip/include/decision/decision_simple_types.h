//
// File: decision_simple_types.h
//
// Code generated for Simulink model 'decision_simple'.
//
// Model version                  : 1.770
// Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
// C/C++ source code generated on : Tue May 14 19:44:10 2019
//
// Target selection: ert.tlc
// Embedded hardware selection: Freescale->S12x
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_decision_simple_types_h_
#define RTW_HEADER_decision_simple_types_h_
#endif                                 // RTW_HEADER_decision_simple_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
