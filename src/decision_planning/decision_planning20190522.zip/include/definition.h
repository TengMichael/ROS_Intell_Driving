#ifndef DEFINITION_H
#define DEFINITION_H


#endif // DEFINITION_H

#include "global.h"


extern lane lane_test;
extern vehicle veh_test;
extern navi navi_test;
extern vector<obstacle> obs_info;
extern path path_test;
extern vector<path_point> out_path1;
extern decision_planning::traj_point_data traj_temp[1000];
extern uint timestamp;
extern double front_dis;

